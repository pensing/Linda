
  (function () {
    const form = document.getElementById("checkform");

    if (!form) return;

    form.addEventListener("submit", function (e) {
      const errors = [];

      const email = form.email.value.trim();
      const name = form.name.value.trim();
      const phone = form.phone.value.trim();
      const message = form.message.value.trim();
      const tos = form.tos.checked;
      const honeypot = form.website.value.trim();
      //foutmeldingen nog even aanpassen
      // e-mail check
      const emailPattern = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
      if (!emailPattern.test(email)) {
        errors.push("Voer een geldig e-mailadres in.");
      }

      // naam check
      if (name.length < 2) {
        errors.push("Naam moet minimaal 2 tekens bevatten.");
      }

      // telefoonnummer check
      const phonePattern = /^\+?\d{7,15}$/;
      if (!phonePattern.test(phone)) {
        errors.push("Voer een geldig telefoonnummer in.");
      }

      // bericht check
      if (message.length < 10) {
        errors.push("Bericht moet minimaal 10 tekens bevatten.");
      }

      // TOS checkbox check
      if (!tos) {
        errors.push("Je moet akkoord gaan met de voorwaarden.");
      }

      // honeypot check
      if (honeypot !== "") {
        errors.push("Opdonderen.");
      }

      if (errors.length > 0) {
        e.preventDefault(); // stop verzending
        alert("Er is iets iet goed ingevuld:\n\n" + errors.join("\n"));
      }
    });
  })();
// alles word server side ook nog check gedaan
console.log("NOU HIJ DOET HET PAUL!!!!!!");